var searchData=
[
  ['representation',['Representation',['../classOnlineMapsHereRoutingAPI.html#a749224a94d252c90ae2edd22ed05c1e1',1,'OnlineMapsHereRoutingAPI']]],
  ['requesttype',['RequestType',['../classOnlineMapsWWW.html#a851a436cdda6e08a8522f4a870405e03',1,'OnlineMapsWWW']]],
  ['rooftype',['RoofType',['../classOnlineMapsBuildingBase.html#a7b68fdef2c1d983da3c2395129b07a9c',1,'OnlineMapsBuildingBase']]],
  ['routeattributes',['RouteAttributes',['../classOnlineMapsHereRoutingAPI.html#a846bab0c5c7afd9dfc4c1af41e341d73',1,'OnlineMapsHereRoutingAPI']]]
];
